<?php
$noda_ip= "";
$host_db = "localhost";
$database_db = "";
$user_db = "";
$password_db = "";
$prefix_db = "";
$noda_wallet= "";
$noda_trust[]= "";
$noda_trust[]= "";
$noda_trust[]= "";
$ip_trust[]= "";
$history_day= 365;
$history_size= 0;
$email_domain= "";
$email_limit= 10;
$email_delay= 0.1;
$noda_site= "";
$fast_first_synch_bd= 1;
?>